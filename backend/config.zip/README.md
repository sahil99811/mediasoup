room:<AssessmentId>
roomName
producersTransport:{}
producers:{}
consumersTransport:{}
consumers:{}
router

user:<userId>
producerTransport
consumerTransport
roomName
producer
consumer
userId



testRoom:<Roomname>
roomName
router

<roomName>:candidate:userId
userId
name
videoProducerTransport
audioProducerTransport
videoProducer
audioProducer

<roomName>:owner:userId
userId
audioConsumerTransport
videoConsumerTransport
audioConsumer
videoConsumer


